IF OBJECT_ID('airbnb_base') IS NOT NULL
    DROP TABLE airbnb_base;
GO

IF OBJECT_ID('airbnb_base2') IS NOT NULL
    DROP TABLE airbnb_base2;
GO

IF OBJECT_ID('review_summary') IS NOT NULL
    DROP TABLE review_summary;
GO

IF OBJECT_ID('listing') IS NOT NULL
    DROP TABLE listing;
GO

IF OBJECT_ID('location') IS NOT NULL
    DROP TABLE location;
GO

IF OBJECT_ID('neighbourhood') IS NOT NULL
    DROP TABLE neighbourhood;
GO


IF OBJECT_ID('neighbourhood') IS NOT NULL
    DROP TABLE neighbourhood;
GO

IF OBJECT_ID('host') IS NOT NULL
    DROP TABLE host;
GO

